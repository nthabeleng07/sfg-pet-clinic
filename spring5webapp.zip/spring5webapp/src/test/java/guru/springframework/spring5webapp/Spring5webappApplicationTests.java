package guru.springframework.spring5webapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring5webappApplicationTests {

	@Test
	void contextLoads() {
	}

}
